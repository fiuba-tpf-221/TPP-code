// jsdom no trae TextEncoder ni WebCrypto: se toman de Node.
const { TextEncoder } = require('util');
const { webcrypto } = require('crypto');

if (!globalThis.TextEncoder) globalThis.TextEncoder = TextEncoder;
Object.defineProperty(globalThis, 'crypto', { value: webcrypto, configurable: true });

// Las pruebas del mock (usuarios, permisos, login simulado) corren con el proveedor simulado.
// Las de Keycloak lo cambian puntualmente.
require('./config/features').FEATURES.AUTH_PROVIDER = 'mock';
require('./config/features').FEATURES.SIMULATE_INFRA = false; // las pruebas del panel Sistema controlan `fetch` a mano
