# Pruebas manuales

Cada fila: **qué hacer** → **qué tiene que pasar**. Si algo no coincide, anotar el número de prueba y qué se vio.
La aplicación tiene dos modos (ver el README): **simulado** (por defecto, no necesita Docker) y **Keycloak** (integración real).
Hacé primero el bloque **S** (simulado); el bloque **K** es para cuando quieras verificar la integración con la infraestructura.

---

# Parte 1 — Modo simulado (ambiente controlado)

## S0. Preparación

Elegí una de las dos formas:

- **Sin Docker** (la más rápida): dentro de `frontend/` ejecutar `npm install` y `npm start` → abrir http://localhost:3000
  (si el puerto está ocupado, la consola indica otro).
- **Con Docker**: en la carpeta del proyecto, `docker compose up -d --build` → abrir http://localhost. Sin tocar nada queda en modo simulado.

Usuario de prueba: `demo@tpp.com` / `demo1234` (Administrador).

Para **volver los datos al estado inicial** en cualquier momento: DevTools del navegador (F12) → *Application* → *Storage* → *Clear site data*.

## S1. Acceso

| # | Qué hacer | Qué tiene que pasar |
|---|---|---|
| S1.1 | Abrir la aplicación | Pantalla de acceso con carrusel a la izquierda y ventana a la derecha, con pestañas *Iniciar sesión / Crear cuenta*. Debajo del nombre del proyecto, la pastilla ámbar **"Modo simulado"**, y al pie de la ventana "Demo (Administrador): demo@tpp.com / demo1234". |
| S1.2 | Dejar vacío el email o la contraseña | El botón *Iniciar sesión* está **deshabilitado**; se habilita solo con ambos campos completos y vuelve a deshabilitarse si uno se vacía. |
| S1.3 | Apretar el ojito del campo contraseña | Muestra y oculta el texto. |
| S1.4 | Entrar con una contraseña incorrecta | Caja roja: "No fue posible iniciar sesión. Verificá tus credenciales o contactá a un administrador." (el mismo mensaje con un email inexistente). |
| S1.5 | Tres contraseñas incorrectas seguidas con `demo@tpp.com`, y luego la correcta | Siempre el mismo mensaje; la cuarta, aunque sea la correcta, **sigue sin entrar** (credencial bloqueada). Para desbloquear: *Clear site data* (S0). |
| S1.6 | Entrar con `demo@tpp.com` / `demo1234` | Inicio con "Bienvenido, Usuario Demo". En la barra superior, la pastilla "Modo simulado". |
| S1.7 | Cerrar sesión desde el menú del usuario (arriba a la derecha) | Vuelve al acceso. Con el botón *Atrás* del navegador no se ve ninguna pantalla interna. |
| S1.8 | Sin sesión, escribir a mano `/usuarios` | Lleva al acceso y, al iniciar sesión, **vuelve a /usuarios**. |

## S2. Todas las pestañas

| # | Qué hacer | Qué tiene que pasar |
|---|---|---|
| S2.1 | Mirar el menú lateral | Siete opciones, cada una con su ícono a la izquierda: **Administración** (Usuarios, Roles, Dominios, Auditoría, Sistema), **Modelos** y **Predicción**. |
| S2.2 | Abrir Roles, Dominios, Auditoría, Modelos y Predicción | Cada una carga y dice "Este módulo está en construcción". |
| S2.3 | Abrir Usuarios y Sistema | Son pantallas reales (ver S3 y S4). |
| S2.4 | Menú del usuario → *Mi perfil* | Nombre "Usuario Demo", Email `demo@tpp.com`, Roles "Administrador". |

## S3. Panel Sistema (simulado)

| # | Qué hacer | Qué tiene que pasar |
|---|---|---|
| S3.1 | Abrir *Administración → Sistema* | Aviso azul "Modo simulado: estos estados no vienen de los servicios reales…" y un selector **Escenario simulado**. Seis tarjetas (Keycloak Auth, MinIO S3, FastAPI Backend, PostgreSQL, RabbitMQ, Redis Cache) en **En línea**, y "6 de 6 servicios en línea". |
| S3.2 | Elegir *Backend degradado (RabbitMQ caído)* | Se actualiza solo: FastAPI Backend **Degradado**, RabbitMQ **Desconectado**, las otras cuatro En línea. |
| S3.3 | Elegir *Backend caído* | FastAPI Backend **Desconectado**; PostgreSQL, RabbitMQ y Redis en **Sin datos**; "2 de 6". |
| S3.4 | Elegir *Keycloak caído* | Keycloak Auth **Desconectado**; el resto En línea. |
| S3.5 | *Actualizar* | Vuelve a consultar y actualiza la hora de "Última verificación". |
| S3.6 | Mirar las seis consolas (Grafana, RabbitMQ, MinIO, Jaeger, Prometheus, SonarQube) | Seis tarjetas con ícono; abren en otra pestaña. Cargan solo si la infraestructura está levantada. |

## S4. Usuarios

| # | Qué hacer | Qué tiene que pasar |
|---|---|---|
| S4.1 | Abrir *Usuarios* | Tabla con `demo@tpp.com`. Sin aviso de "datos de demostración" (en este modo todo es simulado). |
| S4.2 | *Nuevo usuario* con nombre `  Ana   María ` (espacios de más), apellido, email `ana@tpp.com` y rol *Consulta* | Al salir de cada campo se ve el valor normalizado. El botón *Crear usuario* está deshabilitado mientras falte nombre, apellido, email o un rol. |
| S4.3 | Crear con un email de dominio no habilitado (`x@viejo.com`) | Rechaza e informa el error en el campo del email. |
| S4.4 | Crear con datos válidos | Muestra la **contraseña temporal una sola vez** con botón *Copiar* y aviso; *Continuar* vuelve a la lista. |
| S4.5 | Cerrar sesión y entrar con `ana@tpp.com` y la contraseña temporal | Lleva a **Cambiar contraseña** (sin menús). La nueva debe coincidir, tener 8–64 caracteres y no tener espacios; no puede ser igual a la anterior. Al guardar, entra al Inicio. |
| S4.6 | Con ese usuario (rol *Consulta*) mirar el Inicio | Sin menú lateral; "Todavía no tenés permisos asignados. Contactá a un administrador." |
| S4.7 | Con ese usuario, escribir a mano `/usuarios` y `/sistema` | "Sin acceso — No tenés permiso para ver esta pantalla." |
| S4.8 | Crear usuarios con rol *Analista* y con rol *Operador*, e ingresar con cada uno | Analista ve **Modelos** y **Predicción**; Operador ve solo **Predicción**. |
| S4.9 | Como administrador, en la lista: filtrar por email (en mayúsculas), por apellido, por Activo y por uno o más roles; ordenar una columna; pasar de página | Los filtros se combinan; los roles inactivos se marcan con `(*)`; el orden y los filtros se mantienen al paginar y al recargar (F5). Sin coincidencias: "No se encontraron resultados." |
| S4.10 | Entrar al detalle de otro usuario, cambiar el apellido y guardar | *Guardar cambios* está deshabilitado mientras no haya cambios; no se puede quitar el último rol; el email es de solo lectura. |
| S4.11 | Entrar al detalle de **tu propio** usuario | Campos deshabilitados y sin acciones administrativas ("No se habilitan acciones administrativas sobre tu propio usuario"). |
| S4.12 | Dar de baja a otro usuario (confirmando) y luego reactivarlo | Cada acción pide confirmación con su texto; la baja informa el resultado; al reactivar se muestra una **contraseña temporal nueva** y la anterior deja de servir. |

## S5. Sesión

| # | Qué hacer | Qué tiene que pasar |
|---|---|---|
| S5.1 | Copiar `frontend/.env.example` como `frontend/.env`, poner `REACT_APP_SESSION_TIMEOUT_SECONDS=20` y reiniciar `npm start` (con Docker: reconstruir). Entrar y **no hacer clic en el menú** | A los 20–30 s vuelve al acceso con el aviso azul "Tu sesión expiró por inactividad. Iniciá sesión nuevamente." Mover el mouse o escribir no cuenta como actividad. |
| S5.2 | Con el mismo timeout, entrar y a los ~15 s abrir *Usuarios* | Ese uso cuenta como actividad: el contador se reinicia y no cierra a los 30 s. |
| S5.3 | Al terminar, vaciar la variable | Vuelve a 30 minutos. |

## S6. Despliegue (solo con Docker)

| # | Qué hacer | Qué tiene que pasar |
|---|---|---|
| S6.1 | Con sesión iniciada, abrir `/usuarios/nuevo` y recargar (F5) | Sigue en esa pantalla; no hay 404. |
| S6.2 | `npm test -- --watchAll=false` (dentro de `frontend/`) | Todos los tests en verde. |

---

# Parte 2 — Modo Keycloak (integración real)

Entrar siempre por **http://localhost** (no por la IP de la máquina: el login con Keycloak necesita `localhost` o HTTPS).

## K0. Preparación (una sola vez)

1. Activar el modo: en `frontend/.env` poner `REACT_APP_MODE=keycloak` y ejecutar `docker compose up -d --build frontend`.
   (Alternativa sin reconstruir: `npm run start:keycloak` dentro de `frontend/`, abriendo http://localhost:3000.)
2. Con la infraestructura levantada (`docker compose ps -a` con todo en `Up`; Keycloak tarda 1–2 minutos más en estar listo), **crear los roles en Keycloak**
   (el realm no trae ninguno):
   - Abrir http://localhost:8080 → *Administration Console* → usuario `admin`, contraseña `admin`.
   - Arriba a la izquierda, cambiar el realm `master` por **`tpp-realm`**.
   - *Realm roles* → *Create role* → crear `administrador`, `analista`, `operador` y `consulta` (el nombre exacto, en minúsculas).
   - *Users* → `testuser` → pestaña *Role mapping* → *Assign role* → marcar `administrador` → *Assign*.
   - *Users* → *Add user* → usuario `operador1` → *Create* → pestaña *Credentials* → *Set password* `Test1234!` con *Temporary* en **Off** →
     pestaña *Role mapping* → asignar `operador`.

   Los roles quedan en la base de datos de Keycloak: se pierden con `docker compose down -v`.

Credenciales: **la app** usa `testuser` / `password123` (administrador) y `operador1` / `Test1234!`. La **consola de Keycloak** usa `admin` / `admin`
(es otra cuenta: no sirve para entrar a la app).

## K-A. Arranque y rutas

| # | Qué hacer | Qué tiene que pasar |
|---|---|---|
| KA1 | Abrir http://localhost | Se ve **nuestra** pantalla (carrusel y ventana con pestañas), **sin** la pastilla "Modo simulado". Un instante antes puede verse "Conectando con el servicio de autenticación…". |
| KA2 | Sin sesión, abrir http://localhost/usuarios | Lleva al acceso; al iniciar sesión, **vuelve a /usuarios**. |
| KA3 | Con sesión, ir a *Usuarios → Nuevo usuario* y recargar (F5) | Sigue en esa pantalla; no hay 404. |

## K-B. Inicio de sesión

| # | Qué hacer | Qué tiene que pasar |
|---|---|---|
| KB1 | *Iniciar sesión* | Te lleva a la pantalla de Keycloak (URL `localhost:8080/realms/tpp-realm/...`). |
| KB2 | Poner una contraseña incorrecta | Keycloak lo informa y te deja ahí. |
| KB3 | Entrar con `testuser` / `password123` | Vuelve a la app, en Inicio, con **testuser** arriba a la derecha. |
| KB4 | Menú del usuario → *Mi perfil* | Usuario `testuser`, Email `—`, Roles `administrador`. |
| KB5 | Recargar (F5) en cualquier pantalla | Sigue con la sesión iniciada, sin pedir credenciales. Otra pestaña con http://localhost también entra directo. |
| KB6 | Cerrar sesión, pestaña *Crear cuenta* → botón *Crear cuenta* | Abre el registro de Keycloak; al completarlo vuelve a la app con la sesión iniciada y el nombre real. Sin menú lateral y con "Todavía no tenés permisos asignados". |

## K-C. Permisos y menú

| # | Qué hacer | Qué tiene que pasar |
|---|---|---|
| KC1 | Entrar con `testuser` (administrador) | Menú lateral completo: Administración (Usuarios, Roles, Dominios, Auditoría, Sistema), Modelos y Predicción. |
| KC2 | Cerrar sesión y entrar con `operador1` | Solo **Predicción**. Escribiendo `/usuarios` a mano: "Sin acceso". |
| KC3 | En Keycloak, asignarle también `analista` a `operador1`; cerrar sesión y **volver a entrar** | Ahora aparecen **Modelos** y **Predicción** (los roles se leen al iniciar sesión). |

## K-D. Cierre de sesión y timeout

| # | Qué hacer | Qué tiene que pasar |
|---|---|---|
| KD1 | Menú del usuario → *Cerrar sesión*, y luego *Iniciar sesión* | **Keycloak pide credenciales** (no entra solo). |
| KD2 | Con `REACT_APP_SESSION_TIMEOUT_SECONDS=20` (y reconstruir), entrar y no hacer clic en el menú | A los 20–30 s vuelve al acceso con el aviso de sesión expirada; al volver a entrar, Keycloak pide credenciales. |

## K-E. Sistema (real)

| # | Qué hacer | Qué tiene que pasar |
|---|---|---|
| KE1 | *Administración → Sistema* | Sin aviso de modo simulado ni selector. Seis tarjetas **En línea** y "6 de 6 servicios en línea · Última verificación: hh:mm:ss". |
| KE2 | `docker compose stop rabbitmq` → *Actualizar* | RabbitMQ **Desconectado** y FastAPI Backend **Degradado**. `docker compose start rabbitmq` → *Actualizar* → vuelve a 6 de 6. |
| KE3 | `docker compose stop minio` → *Actualizar* | MinIO **Desconectado** y el backend **Degradado**. Volver a iniciarlo. |
| KE4 | `docker compose stop backend` → *Actualizar* | FastAPI Backend **Desconectado**; PostgreSQL, RabbitMQ y Redis en **Sin datos**; "2 de 6". Volver a iniciarlo. |
| KE5 | `docker compose stop keycloak` → *Actualizar* | Keycloak **Desconectado**; la sesión abierta sigue. |
| KE6 | Con Keycloak detenido, recargar (F5) | Tras unos 15 s: "No se pudo conectar con el servicio de autenticación…" con botón **Reintentar**. Iniciar Keycloak, esperar ~1 min y *Reintentar*. |
| KE7 | Las seis consolas | Abren en otra pestaña y cargan: Grafana (3001), RabbitMQ (15672), MinIO (9001), Jaeger (16686), Prometheus (9090), SonarQube (9000, tarda en iniciar). |

## K-F. Usuarios en modo Keycloak

| # | Qué hacer | Qué tiene que pasar |
|---|---|---|
| KF1 | Abrir *Usuarios*, *Nuevo usuario* y el detalle de un usuario | En las tres aparece el aviso azul "Datos de demostración: los usuarios de esta pantalla son simulados y no existen en Keycloak…". |
| KF2 | Crear un usuario, filtrar, ordenar, editar, dar de baja | Funciona igual que en S4. Esos usuarios **no existen en Keycloak** y no pueden iniciar sesión en él. |

---

## Si algo falla

- **Se queda en "Conectando…" o aparece el error de autenticación (modo Keycloak)**: Keycloak todavía no está listo (esperar 1–2 minutos) o está caído → `docker compose logs keycloak`.
- **En modo Keycloak entré pero no veo el menú**: el usuario no tiene roles en Keycloak → K0, paso 2.
- **Cambié algo y no se ve**: con Docker, `docker compose up -d --build frontend` y recargar con Ctrl+F5; con `npm start`, reiniciarlo. Las variables `REACT_APP_*` solo se aplican al construir o iniciar.
- **No sé en qué modo estoy**: si ves la pastilla ámbar "Modo simulado" (en el acceso y en la barra superior), es el simulado. Si no la ves, es Keycloak.
