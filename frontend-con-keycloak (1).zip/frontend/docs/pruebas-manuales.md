# Pruebas manuales

Cada fila: **qué hacer** → **qué tiene que pasar**. Si algo no coincide, anotar el número de prueba y qué se vio.
Entrar siempre por **http://localhost** (no por la IP de la máquina: el login con Keycloak necesita `localhost` o HTTPS).

## 0. Preparación (una sola vez)

1. En la carpeta del proyecto **viejo**: `docker compose down` (si no, los puertos 80, 8000, 5432… quedan ocupados).
2. En la carpeta del proyecto **nuevo** (el de tu compañero con este `frontend/`): `docker compose up -d --build`. La primera vez tarda varios minutos.
   Esperar ~1–2 minutos más a que Keycloak termine de arrancar. `docker compose ps` debe mostrar todo en `Up`.
3. **Crear los roles en Keycloak** (el realm no trae ninguno):
   - Abrir http://localhost:8080 → *Administration Console* → usuario `admin`, contraseña `admin`.
   - Arriba a la izquierda, cambiar el realm `master` por **`tpp-realm`**.
   - *Realm roles* → *Create role* → crear `administrador`, `analista`, `operador` y `consulta` (el nombre exacto, en minúsculas).
   - *Users* → `testuser` → pestaña *Role mapping* → *Assign role* → marcar `administrador` → *Assign*.
   - *Users* → *Add user* → usuario `operador1` → *Create* → pestaña *Credentials* → *Set password* `Test1234!` con *Temporary* en **Off** →
     pestaña *Role mapping* → asignar `operador`.

   Los roles quedan guardados en la base de datos de Keycloak: se pierden si se hace `docker compose down -v`.

Usuarios de prueba: `testuser` / `password123` (administrador) y `operador1` / `Test1234!` (operador).

## A. Arranque y rutas

| # | Qué hacer | Qué tiene que pasar |
|---|---|---|
| A1 | Abrir http://localhost | Se ve **nuestra** pantalla (carrusel a la izquierda, ventana con pestañas *Iniciar sesión / Crear cuenta*), no la de Keycloak. Un instante antes puede verse "Conectando con el servicio de autenticación…". |
| A2 | Con la pantalla de acceso abierta, recargar (F5) | Sigue ahí; no aparece un 404. |
| A3 | Sin sesión, abrir http://localhost/usuarios | Te lleva a la pantalla de acceso. Al iniciar sesión, **vuelve a /usuarios**. |
| A4 | Con sesión, ir a *Usuarios → Nuevo usuario* y recargar (F5) | Sigue en esa pantalla; no hay 404. |

## B. Inicio de sesión (Keycloak)

| # | Qué hacer | Qué tiene que pasar |
|---|---|---|
| B1 | *Iniciar sesión* | Te lleva a la pantalla de Keycloak (la URL empieza con `localhost:8080/realms/tpp-realm`). |
| B2 | Poner una contraseña incorrecta | Keycloak lo informa y te deja ahí. |
| B3 | Entrar con `testuser` / `password123` | Vuelve a la app, en Inicio. Arriba a la derecha dice **testuser**. |
| B4 | Menú del usuario → *Mi perfil* | Usuario `testuser`, Email `—`, Roles `administrador`. |
| B5 | Recargar (F5) en cualquier pantalla | Sigue con la sesión iniciada, sin pedir credenciales. |
| B6 | Abrir http://localhost en **otra pestaña** | Entra directo (sesión compartida). |
| B7 | Cerrar sesión, ir a *Crear cuenta* → botón *Crear cuenta* | Abre el registro de Keycloak. Completar el alta (usuario, email, nombre, apellido, contraseña) → vuelve a la app con la sesión iniciada y el **nombre real**. No hay menú lateral y el Inicio dice "Todavía no tenés permisos asignados. Contactá a un administrador." |

## C. Permisos y menú

| # | Qué hacer | Qué tiene que pasar |
|---|---|---|
| C1 | Entrar con `testuser` (administrador) | Menú lateral: **Administración** (Usuarios, Roles, Dominios, Auditoría, Sistema), **Modelos** y **Predicción**. Cada ícono a la izquierda del texto. |
| C2 | Cerrar sesión y entrar con `operador1` | El menú muestra **solo Predicción**. |
| C3 | Con `operador1`, escribir a mano http://localhost/usuarios | "Sin acceso — No tenés permiso para ver esta pantalla." Lo mismo en `/sistema`. |
| C4 | En Keycloak, asignarle también `analista` a `operador1`. **Cerrar sesión y volver a entrar** | Ahora aparecen **Modelos** y **Predicción**. (Los roles se leen al iniciar sesión.) |
| C5 | Con el usuario creado en B7 (sin roles) abrir `/sistema` | "Sin acceso". |

## D. Cierre de sesión y timeout

| # | Qué hacer | Qué tiene que pasar |
|---|---|---|
| D1 | Menú del usuario → *Cerrar sesión*, y luego *Iniciar sesión* | Vuelve a la pantalla de acceso; al iniciar, **Keycloak pide credenciales** (no entra solo). |
| D2 | Tras cerrar sesión, botón *Atrás* del navegador | No muestra pantallas internas: te manda al acceso. |
| D3 | Copiar `frontend/.env.example` como `frontend/.env`, poner `REACT_APP_SESSION_TIMEOUT_SECONDS=20` y reconstruir: `docker compose up -d --build frontend`. Entrar y **no hacer clic en el menú** (mover el mouse o escribir no cuenta) | A los 20–30 s vuelve a la pantalla de acceso con el aviso azul "Tu sesión expiró por inactividad. Iniciá sesión nuevamente." Al volver a entrar, Keycloak pide credenciales. |
| D4 | Con el mismo timeout, entrar y a los ~15 s abrir *Usuarios* | Ese uso reinicia el contador: no se cierra a los 30 s. |
| D5 | Al terminar, vaciar la variable y reconstruir | Vuelve a 30 minutos. |

## E. Sistema

| # | Qué hacer | Qué tiene que pasar |
|---|---|---|
| E1 | *Administración → Sistema* | 6 tarjetas (Keycloak Auth, MinIO S3, FastAPI Backend, PostgreSQL, RabbitMQ, Redis Cache) en **En línea**; arriba "6 de 6 servicios en línea · Última verificación: hh:mm:ss". |
| E2 | Abrir cada consola | Se abren en otra pestaña y cargan: Grafana (3001), RabbitMQ (15672), MinIO (9001), Jaeger (16686), Prometheus (9090), SonarQube (9000, tarda en iniciar). |
| E3 | `docker compose stop rabbitmq` → *Actualizar* | RabbitMQ **Desconectado** y FastAPI Backend **Degradado**; el resto En línea. `docker compose start rabbitmq` → *Actualizar* → vuelve a 6 de 6. |
| E4 | `docker compose stop minio` → *Actualizar* | MinIO **Desconectado** y el backend **Degradado**. Volver a iniciarlo. |
| E5 | `docker compose stop backend` → *Actualizar* | FastAPI Backend **Desconectado**; PostgreSQL, RabbitMQ y Redis en **Sin datos** (no "Desconectado"); "2 de 6". Volver a iniciarlo. |
| E6 | Con la sesión abierta: `docker compose stop keycloak` → *Actualizar* | Keycloak **Desconectado**; la sesión sigue abierta. |
| E7 | Con Keycloak detenido, recargar (F5) | Tras unos 15 s: "No se pudo conectar con el servicio de autenticación…" con botón **Reintentar**. `docker compose start keycloak`, esperar ~1 min, *Reintentar* → vuelve a funcionar. |

## F. Usuarios (datos de demostración)

| # | Qué hacer | Qué tiene que pasar |
|---|---|---|
| F1 | Abrir *Usuarios*, *Nuevo usuario* y el detalle de un usuario | En las tres aparece el aviso azul "Datos de demostración: los usuarios de esta pantalla son simulados y no existen en Keycloak…". |
| F2 | Crear un usuario | Muestra la contraseña temporal **una sola vez**; "Continuar" vuelve a la lista. |
| F3 | Filtrar (por email, apellido, rol), ordenar una columna y pasar a la página 2 | Filtros y orden se mantienen al paginar; recargar (F5) los conserva. |
| F4 | Entrar al detalle, cambiar el apellido y guardar | Se guarda; el botón *Guardar cambios* está deshabilitado mientras no haya cambios. |
| F5 | Dar de baja y reactivar a un usuario | Ambas piden confirmación; al reactivar se muestra una contraseña temporal nueva. |

> Estos usuarios son del mock del navegador: no existen en Keycloak y no pueden iniciar sesión en él.

## G. Sin infraestructura (solo interfaz)

| # | Qué hacer | Qué tiene que pasar |
|---|---|---|
| G1 | En `frontend/.env` poner `REACT_APP_AUTH_PROVIDER=mock`; dentro de `frontend/`: `npm install` y `npm start` | Abre la app (http://localhost:3000, u otro puerto si está ocupado) con el **login clásico** (email y contraseña). Entrar con `demo@tpp.com` / `demo1234`. **No** aparece el aviso de datos de demostración. |
| G2 | Tres contraseñas incorrectas seguidas con `demo@tpp.com` | Siempre el mismo mensaje genérico; a la cuarta, aunque sea la correcta, sigue sin entrar. |
| G3 | `npm test -- --watchAll=false` | Todos los tests en verde. |

## Si algo falla

- **Se queda en "Conectando…" o aparece el error de autenticación**: Keycloak todavía no está listo (esperar 1–2 minutos) o está caído → `docker compose logs keycloak`.
- **Entré pero no veo el menú**: el usuario no tiene roles en Keycloak → preparación, paso 3.
- **Cambié algo y no se ve**: `docker compose up -d --build frontend` y recargar con Ctrl+F5. Las variables `REACT_APP_*` solo se aplican al construir.
- **Keycloak da error al volver a la app o se queda dando vueltas**: probar con http://localhost (no con la IP) y en una ventana sin extensiones que bloqueen contenido.
