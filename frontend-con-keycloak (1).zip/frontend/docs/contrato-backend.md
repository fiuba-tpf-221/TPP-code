# Contrato front–backend

> **Estado actual (octubre 2026):** el backend real (`backend/app/main.py`) solo expone `GET /health`, `GET /files` y
> `POST /files/test-upload`. **Ninguno de los endpoints de abajo existe todavía**: por eso `USE_MOCK_API` sigue en `true`.
> El único contrato que el front ya consume del backend real es `GET /health` (ver al final).

Mientras `FEATURES.USE_MOCK_API` esté en `true`, todo lo de acá lo resuelve
`src/mock/` (una base en el navegador). Cuando el backend esté listo:

1. Poner `USE_MOCK_API: false` en `src/config/features.js`.
2. Borrar la carpeta `src/mock/` (nada de ahí es parte del producto real).
3. Implementar estos endpoints. Todos van con `Authorization: Bearer <token>`.

## Autenticación

El front tiene dos modos (`FEATURES.AUTH_PROVIDER` en `src/config/features.js`, o `REACT_APP_AUTH_PROVIDER=mock`):

- **`keycloak` (por defecto)**: autentica el Keycloak de la infraestructura (realm `tpp-realm`, cliente público `frontend-client`, flujo estándar
  con PKCE). El front manda `Authorization: Bearer <access token>` en cada llamada a `/api` y **renueva el token** antes de enviarla.
  Lo que debe hacer el backend: **validar ese JWT** (firma con las claves públicas del realm, `iss`, expiración) y responder **401** si no sirve.
  Hoy no lo hace (`core/security.py` y `api/endpoints/auth.py` están vacíos).
- **`mock`**: login simulado en el navegador; sirve para trabajar la interfaz sin levantar la infraestructura. Es lo que describe la tabla siguiente.

### Permisos con Keycloak

El token de Keycloak trae **roles** (`realm_access.roles`), no los permisos de la US-06. Mientras el backend no los entregue, el front los deriva con la tabla
provisoria `src/config/keycloakRoles.js` (rol del realm → permisos). Los roles deben existir en Keycloak con esos nombres: `administrador`, `analista`,
`operador`, `consulta`. **Recomendado:** `GET /api/me` devolviendo `{ id, name, email, roles, permissions }` con los permisos *efectivos* (US-06), y borrar esa tabla.

### Qué cubre Keycloak y qué queda del lado de la infraestructura (US-05)

Con Keycloak, estas reglas de la US-05 ya no las implementa el front sino la **configuración del realm** (consola de Keycloak → Realm settings):
bloqueo tras 3 intentos fallidos (*Brute force detection*), política de contraseña (8–64 caracteres), contraseña temporal con cambio obligatorio
(*Required action: Update Password*), vencimiento por inactividad (*SSO Session Idle*, 30 minutos), y mensaje genérico ante fallas.
El realm actual (`keycloak/realm-export.json`) **no tiene ninguna** de esas reglas configurada y tiene `registrationAllowed: true`
(cualquiera puede crear una cuenta desde la pantalla de Keycloak). La regla de "dominio activo" y la auditoría de logins no existen en Keycloak: requieren
backend (o un evento/SPI de Keycloak).

### Modo `mock` (US-05)

| Endpoint | Body | Respuesta / notas |
|---|---|---|
| `POST /api/auth/login` | `{ email, password }` | `{ token, user }`. Ante cualquier falla: 401 con el mensaje genérico (no revelar el motivo real; auditarlo del lado del servidor). |
| `POST /api/auth/google` | `{ credential }` | Igual que login. El backend **debe verificar la firma** del JWT de Google y que el `aud` sea su Client ID. |
| `POST /api/auth/change-password` | `{ newPassword }` | `{ token, user }` con `mustChangePassword: false`. No pide la contraseña anterior (ya se validó en el login). |
| `POST /api/auth/register` | `{ name, email, password }` | `{ token, user }`. Solo si se mantiene el autoregistro. |
| `POST /api/auth/logout` | — | Invalida solo la sesión actual. |

Solo modo `mock`. `user` siempre trae: `{ id, name, email, roles: [{id,name}], permissions: string[], mustChangePassword }`.

## Usuarios (US-01 y US-02)

| Endpoint | Body | Respuesta / notas |
|---|---|---|
| `GET /api/users` | query (ver abajo) | `{ items, total, page, pageSize }`. Requiere permiso `users.manage`. |
| `GET /api/roles` | — | `[{ id, name, active }]`, incluye inactivos (el front filtra según la pantalla). |
| `GET /api/users/:id` | — | Detalle: agrega `blocked`, `failedAttempts`, `mustChangePassword`. |
| `POST /api/users` | `{ firstName, lastName, email, active, roleIds }` | `{ user, temporaryPassword }`. La contraseña se muestra una sola vez: no se vuelve a exponer en ningún GET posterior. |
| `PUT /api/users/:id` | `{ firstName, lastName, roleIds }` | Solo estos 3 campos. Email inmutable. Auditar valor anterior y nuevo por campo modificado. Rechazar si `id` es el propio actor (403). |
| `POST /api/users/:id/deactivate` | — | Rechazar sobre uno mismo (403). |
| `POST /api/users/:id/reactivate` | — | `{ user, temporaryPassword }`, una sola vez. **Siempre** genera contraseña temporal nueva (la anterior queda inválida) y deja `active=true`, `blocked=false`, `failedAttempts=0`, `mustChangePassword=true`. No cierra sesiones abiertas. Rechazar sobre uno mismo (403). |
| `POST /api/users/:id/temporary-password` | — | `{ user, temporaryPassword }`, una sola vez. Rechazar sobre uno mismo (403). |

### Consulta de usuarios (US-04)

`GET /api/users?email=&firstName=&lastName=&active=&blocked=&roleIds=a,b&sort=email&order=asc&page=1&pageSize=10`

- `email`, `firstName`, `lastName`: coincidencia parcial, sin distinguir mayúsculas.
- `active`, `blocked`: `true` / `false`; si se omiten, no filtran.
- `roleIds`: lista separada por comas; un usuario cumple si tiene **al menos uno** (OR). Vacío = no filtra. Se aceptan roles inactivos.
- Los distintos filtros se combinan con **AND**.
- `sort`: `email | firstName | lastName | active | blocked` (Roles no se ordena); `order`: `asc | desc`. Ante empate, desempatar por email.
- Cada ítem: `{ id, firstName, lastName, email, active, blocked, roles: [{ id, name }] }`.
- Si `page` excede el total, devolver la última página existente.

Errores de validación: `4xx` con `{ detail, field? }`; `field` es el nombre del campo del formulario (`email`, `firstName`, `roleIds`, etc.) para que el front lo marque en el lugar correcto.

## Seguridad (no delegable al front)

- Las contraseñas se hashean con un algoritmo lento y con sal (bcrypt, argon2, scrypt). El mock usa SHA-256 con sal solo para simular la forma del dato; **no es apto para producción**.
- El permiso `users.manage` (y el resto) se valida en cada endpoint, no solo se oculta en el menú.
- El JWT de Google se verifica del lado del servidor.

## Módulos y permisos (US-06)

Catálogo **definido por el sistema** (sin ABM en la aplicación):

- Módulo: `{ code, name, description, active, order }`. Iniciales: Administración, Modelos, Predicción.
- Permiso: `{ code, description, active, module }` (pertenece a exactamente un módulo).

| Código | Descripción | Módulo |
|---|---|---|
| `users.manage` | Gestión de usuarios | Administración |
| `roles.manage` | Gestión de roles | Administración |
| `domains.manage` | Gestión de dominios | Administración |
| `audit.view` | Consulta de auditoría | Administración |
| `system.view` | Consulta del sistema | Administración |
| `models.manage` | Gestión de modelos | Modelos |
| `predictions.use` | Uso de modelos | Predicción |

**Permisos efectivos** = unión de los permisos de los roles **activos** del usuario, siempre que el permiso **y su módulo** estén activos.
El estado del usuario y del dominio **no** entra en este cálculo (se valida solo al autenticar). Inactivar un módulo o un rol no borra
asociaciones: al reactivarlo, los permisos vuelven a ser efectivos.

El login devuelve en `user.permissions` solo los **códigos efectivos**; el front arma el menú con eso. Eso no reemplaza la validación:
cada endpoint debe verificar el permiso efectivo (403 si no lo tiene), aunque el usuario conozca la URL.

`system.view` (panel **Sistema**) **no figura en la US-06**: se agregó para poder mostrar el panel de infraestructura. Falta confirmar con
el equipo si queda así o si se define una historia para ese módulo.

## Panel Sistema (ya conectado al backend real)

Lo consume `src/features/system/`. No usa el cliente `/api` ni envía token: el backend aún no tiene autenticación.

`GET http://<host>:8000/health` →
```json
{ "status": "ONLINE | DEGRADED", "service": "backend-api",
  "dependencies": { "postgres": "ONLINE|OFFLINE", "rabbitmq": "...", "redis": "...", "minio": "...", "otel": "..." } }
```
El front lee `status`, `postgres`, `rabbitmq` y `redis`. Keycloak (`/realms/tpp-realm`) y MinIO (`:9002/minio/health/live`) se consultan
directo desde el navegador, solo para saber si responden (`no-cors`).

El navegador llama al puerto 8000 directamente porque `nginx/default.conf` no publica `/health` (solo `/api/`, que va a `backend:8000/api/`).
Si se publica por nginx, alcanza con definir `REACT_APP_BACKEND_URL` (ver `.env.example`) y reconstruir.
