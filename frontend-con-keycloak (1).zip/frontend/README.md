# Frontend — fiuba-tpf-221

React 18 + Create React App + React Router 6. Sin librería de UI: estilos propios en CSS.

## Cómo se ejecuta

| Qué | Cómo |
|---|---|
| Todo el stack (producción, como lo levanta el `docker-compose.yml` de la raíz) | `docker compose up -d --build frontend` y abrir http://localhost |
| Desarrollo con recarga al guardar | dentro de `frontend/`: `npm install` y `npm start` (si el 3000 está ocupado, CRA ofrece otro puerto) |
| Tests | `npm test` |
| Build de producción local | `npm run build` |

La imagen compila la app y la sirve con nginx (`nginx.conf` incluido). Ese archivo hace que recargar `/usuarios`, `/sistema`, etc. funcione:
sin él, cualquier ruta que no sea `/` daría 404.

## Autenticación (mix: su Keycloak, nuestra interfaz)

Por defecto el login lo hace el **Keycloak** de la infraestructura (flujo estándar con PKCE, como en la versión original del equipo); la app muestra
su propia pantalla de acceso (carrusel + ventana) y, al apretar **Iniciar sesión**, pasa por Keycloak y vuelve.

- Usuario de prueba del realm: `testuser` / `password123`. **No tiene roles**, así que al entrar ve solo Inicio y Mi perfil.
  Para ver el menú completo hay que crear el rol `administrador` y asignárselo (pasos en `docs/pruebas-manuales.md`).
- La sesión se recupera sola al recargar (Keycloak ya la tiene). Se cierra a los 30 minutos sin actividad o desde el menú del usuario; en ambos casos se
  cierra también en Keycloak, así que el siguiente ingreso pide credenciales.
- Los permisos del menú salen de los roles del realm (`src/config/keycloakRoles.js`, provisorio hasta que el backend los entregue).
- Entrar siempre por **http://localhost**: PKCE necesita un contexto seguro y el navegador solo lo da para `localhost` o HTTPS.

Sin infraestructura (solo para trabajar la interfaz): `REACT_APP_AUTH_PROVIDER=mock` en `.env` y `npm start`. Entonces el login es simulado:
`demo@tpp.com` / `demo1234` (Administrador).

## Estructura

```
src/
├── app/          App.js (providers) y AppRouter.js (todas las rutas)
├── config/       rutas y menú, permisos, features, servicios de infraestructura
├── features/     una carpeta por funcionalidad
│   ├── auth/     acceso (Keycloak o simulado), sesión, permisos
│   ├── users/    consulta, alta y detalle de usuarios
│   ├── system/   panel Sistema (estado de infraestructura y consolas)
│   ├── home/  profile/
├── shared/       componentes, layout, cliente HTTP y utilidades reutilizables
├── mock/         "backend" simulado en el navegador: se borra cuando exista el real
└── styles/       estilos globales
docs/contrato-backend.md   endpoints que el front espera del backend
```

Para **agregar una pantalla**: crear la página en su feature, sumar la `<Route>` en `app/AppRouter.js` y, si va en el menú, un ítem en
`config/routes.js` con el permiso que corresponda (que también debe existir en `mock/db.js` y en el backend).

## Mock vs. backend real

`src/config/features.js` → `USE_MOCK_API: true` usa `src/mock/` (datos en `localStorage`). Cuando el backend implemente los endpoints de
`docs/contrato-backend.md`, se pone en `false` y se borra `src/mock/`. El panel **Sistema** no usa el mock: siempre consulta los servicios reales.

## Panel Sistema

`src/config/services.js` concentra puertos y URLs (los publicados en el `docker-compose.yml`). Se arman con el host desde el que se abrió la app,
así que sirven igual con `localhost` o con la IP de la máquina. Para otro backend: `REACT_APP_BACKEND_URL` en `.env`.

## Variables de entorno

Ver `.env.example`. Las `REACT_APP_*` se incorporan **al construir**: si se cambian, hay que reconstruir la imagen.
