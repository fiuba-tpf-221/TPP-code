import { BACKEND_URL, INFRA_PROBES } from '../../config/services';

const TIMEOUT_MS = 4000;
const KNOWN = ['ONLINE', 'DEGRADED', 'OFFLINE'];
const normalize = (status) => (KNOWN.includes(status) ? status : 'UNKNOWN');

async function request(url, options = {}) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), TIMEOUT_MS);
  try {
    return await fetch(url, { cache: 'no-store', ...options, signal: controller.signal });
  } finally {
    clearTimeout(timer);
  }
}

// Keycloak y MinIO no habilitan CORS para esta app: con `no-cors` solo se puede saber si responden
// (no se lee el contenido ni el código HTTP).
async function probe(url) {
  try {
    await request(url, { mode: 'no-cors' });
    return 'ONLINE';
  } catch {
    return 'OFFLINE';
  }
}

// GET /health del backend -> { status, dependencies: { postgres, rabbitmq, redis, minio, otel } }
async function backendHealth() {
  try {
    const res = await request(`${BACKEND_URL}/health`);
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const data = await res.json();
    const dep = (name) => normalize(data.dependencies?.[name]);
    return { backend: normalize(data.status), postgres: dep('postgres'), rabbitmq: dep('rabbitmq'), redis: dep('redis') };
  } catch {
    // Si el backend no responde, no se puede saber cómo están las dependencias que él consulta: "sin datos".
    return { backend: 'OFFLINE', postgres: 'UNKNOWN', rabbitmq: 'UNKNOWN', redis: 'UNKNOWN' };
  }
}

// Devuelve { keycloak, minio, backend, postgres, rabbitmq, redis } con ONLINE | DEGRADED | OFFLINE | UNKNOWN.
export async function checkInfrastructure() {
  const [keycloak, minio, backend] = await Promise.all([
    probe(INFRA_PROBES.keycloak), probe(INFRA_PROBES.minio), backendHealth(),
  ]);
  return { keycloak, minio, ...backend };
}
