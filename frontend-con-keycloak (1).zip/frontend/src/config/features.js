export const FEATURES = {
  // true = datos simulados en el navegador. Cuando el backend esté listo, pasar a false.
  USE_MOCK_API: true,
  // Pestaña "Crear cuenta" en el login. Ver si otra US la reemplaza por el alta hecha por administradores.
  SELF_REGISTRATION: true,
  // 'keycloak': el login lo hace el Keycloak de la infraestructura (nuestra interfaz, su autenticación).
  // 'mock': login simulado en el navegador; sirve para trabajar la interfaz sin levantar la infraestructura.
  AUTH_PROVIDER: process.env.REACT_APP_AUTH_PROVIDER === 'mock' ? 'mock' : 'keycloak',
};
