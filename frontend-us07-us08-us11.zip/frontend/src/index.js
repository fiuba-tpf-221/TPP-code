import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './app/App';
import './styles/global.css';
import './styles/ui.css';

ReactDOM.createRoot(document.getElementById('root')).render(<App />);
